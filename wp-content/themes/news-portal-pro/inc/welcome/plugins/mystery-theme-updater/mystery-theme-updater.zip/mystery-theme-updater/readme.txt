=== Mystery Theme Updater ===

Contributors: 		Mystery Themes Team
License: 			GNU General Public License v3 or later
License URI: 		http://www.gnu.org/licenses/gpl-3.0.html
Tags: 				upload, upgrade, themes, update, translation-ready
Requires at least: 	4.5
Tested up to: 		4.9
Stable tag: 		1.0.0

Premium Theme Updater | Mystery Themes | Premium Themes

== Description ==

<strong>Mystery Theme Updater</strong> is a simple and lightweight WordPress Theme Updater for our premium themes. Now, you can simple upload your Pro/Premium theme new version zip file from Theme Installer <strong>Appearance >> Themes >> Add New >> Upload</strong>.

== Installation ==
1. Unzip mystery-theme-updater.zip
2. Upload ll the files to the /wp-content/plugins/mystery-theme-updater
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==
= What does this plugin do? =
This plugin helps to upgrade your newer version of the premium theme from WordPress dashboard.

= How can I upgrade the premium theme? =
1. Download the latest zip file for your theme.
2. Log into your WordPress site.
3. Go to Appearance > Themes.
4. Click the "Add New" button at the top of the page.
5. Click the "Upload Theme" button at the top of the page.
6. Select the zip file with the new theme version to install.
7. Click the "Install Now" button.

== Changelog ==

= 1.0.0 =
* Initial Release