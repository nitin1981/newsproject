=== MT Demo Importer ===

Contributors: 		Mystery Themes Team
Tags: 				import, content, demo, theme options, customizer options
Requires at least: 	4.0
Tested up to: 		4.9
Stable tag: 		1.0.0
License: 			GPLv3 or later
License URI: 		http://www.gnu.org/licenses/gpl-3.0.html

A plugin to import your demo content, widgets, theme settings and customizer settings with one click.

== Description ==

<strong>MT Demo Importer</strong> is a <strong>Free WordPress plugin</strong> to import the demo contents, widgets, theme settings and customizer settings with one click in your website!

You just need to create a new instance for the plugin class somewhere in your theme and define the path for the demo content, widgets, theme option settings and customizer settings and the path for the demo folder location.

== Installation ==
1. Upload `mt-demo-imporder` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Create an object instance for the `MT_Demo_Importer` class within your theme file.
4. You may replace these default demo by adding your own demo content files to the theme folder and setting the demo file path location to the `MT_Demo_Importer` object.



== Frequently Asked Questions ==
= What does this plugin do? =
This plugin provides the ability to to import the demo contents, widgets, theme option settings and customizer settings in your site.

== Changelog ==

= 1.0.0 =
	* initial release